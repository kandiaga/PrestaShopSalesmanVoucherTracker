<?php

class SalesmanVoucher extends ObjectModel
{	 public $id_salesman_voucher;              	 public $voucher_name;	 public $voucher_code;	 public $id_employee;     public $id_cart_rule;	
    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'salesman_voucher',
        'primary' => 'id_salesman_voucher',
        'multilang' => FALSE,
        'fields' => array(       		
            'voucher_name'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true, 'size' => 128),
			'voucher_code'=>array('type' => self::TYPE_STRING, 'required' => true, 'size' => 128),
			'id_employee'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true),	            'id_cart_rule'=>array('type' => self::TYPE_STRING, 'validate' => 'isCatalogName', 'required' => true),	  			
        ),
    );
	//get all quotes 	
	public function getAllRelatedVouchers()
	{
	    $sql='';
	    $id_lang = (int)Context::getContext()->language->id; 
		$dbquery = new DbQuery();
		$dbquery->select('d.`id_salesman_voucher` AS `id`, d.`voucher_name` AS `voucher_name`, d.`voucher_code` AS `voucher_code`, d.`id_employee` AS `id_employee`,		d.`id_cart_rule` AS `id_cart_rule`');
		$dbquery->from('salesman_voucher', 'd');			
		$orders = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($dbquery->build());	
		return $orders;		
	}			public static function getCodeById($id_cart_rule)	{		if (!Validate::isInt($id_cart_rule))			return false;		return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT `code` FROM `'._DB_PREFIX_.'cart_rule` WHERE `id_cart_rule` = '.(int)$id_cart_rule);	}			public static function getNameById($id_cart_rule,$id_lang)	{	    		if (!Validate::isInt($id_cart_rule))			return false;		return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('SELECT `name` FROM `'._DB_PREFIX_.'cart_rule_lang` WHERE `id_cart_rule` ='.(int)$id_cart_rule.' AND `id_lang`='.(int)$id_lang);	}				public static function getSalesman($id_employee)	{		$Employee=new Employee($id_employee);				return $Employee->firstname.' '.$Employee->lastname;	}		public static function getCustomer($id_customer)	{		$customer=new Customer($id_customer);				return $customer->firstname.' '.$customer->lastname;	}			public static function usedByCustomers($id_cart_rule)	{		return Db::getInstance()->ExecuteS('		SELECT *		FROM `'._DB_PREFIX_.'order_cart_rule` ocr		LEFT JOIN `'._DB_PREFIX_.'orders` o ON ocr.`id_order` = o.`id_order`		WHERE ocr.`id_cart_rule` = '.(int)$id_cart_rule		);	}				//verify duplicated codes		public static function verifyByCode($query)	{		return Db::getInstance()->getRow('			SELECT iv.`id_salesman_voucher`			FROM `'._DB_PREFIX_.'salesman_voucher` iv						WHERE iv.`voucher_code`  LIKE \''.pSQL($query).'\'		');	}	
}

