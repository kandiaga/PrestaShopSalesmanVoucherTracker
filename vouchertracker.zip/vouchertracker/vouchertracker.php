<?php
/**
* 2007-2017 PrestaShop.
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2016 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once(dirname(__FILE__) . '/classes/SalesmanVoucher.php');   

class vouchertracker extends Module
{
    public function __construct()
    {
          $this->name = 'vouchertracker';
          $this->tab = 'administration';
          $this->version = '1.0.0';
          $this->author = 'NdiagaSoft';
          $this->need_instance = 0;
          $this->secure_key = Tools::encrypt($this->name);
          $this->ps_versions_compliancy = array('min' => '1.5', 'max' => _PS_VERSION_);
          $this->bootstrap = true;

          parent::__construct();

          $this->displayName = $this->l('Salesman Voucher Tracker');
          $this->description = $this->l('Create a coupon code and associate it  to a salesman.');

          $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }
    public function install()
    {
        if (Shop::isFeatureActive()) {
              Shop::setContext(Shop::CONTEXT_ALL);
        }
		
		$sql = array();
	
        $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'salesman_voucher` (
                  `id_salesman_voucher` int(10) unsigned NOT NULL AUTO_INCREMENT,                  
				  `voucher_name` varchar(250) UNIQUE NOT NULL,
				  `voucher_code` varchar(250) UNIQUE NOT NULL,
				  `id_employee` int(11) NOT NULL, 
                  `id_cart_rule` int(11) NOT NULL, 				  
                  PRIMARY KEY (`id_salesman_voucher`)
                ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8';
	

        if (!parent::install() ||
		    !$this->runSql($sql)
           ) 
              return false;             

          return true;
    }

    public function uninstall()
    {
	   $sql = array();
	
        $sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'salesman_voucher`';
		
		
        if (!parent::uninstall() ||
		    !$this->runSql($sql)		
            ) 
              return false;         

          return true;
    }
	
	 public function runSql($sql) {
        foreach ($sql as $s) {
			if (!Db::getInstance()->Execute($s)){
				return FALSE;
			}
        }
        
        return TRUE;
    }	
	
	
	public function getContent()
    {
              $output = null;
			  
			$output.=$this->addVoucher();
			  
			  
	  if(Tools::isSubmit('deletevouchertracker') && Tools::getValue('id_salesman_voucher')!='')
	  {
	    $id_salesman_voucher=Tools::getValue('id_salesman_voucher');
		$Obj=new SalesmanVoucher($id_salesman_voucher);
		$Obj->delete();
	  }
	  
	  if(Tools::isSubmit('viewvouchertracker') && Tools::getValue('id_salesman_voucher')!='')
	  {
	    $id_salesman_voucher=Tools::getValue('id_salesman_voucher');
		$Obj=new SalesmanVoucher($id_salesman_voucher);
		
		$output=$this->renderCodeDetails();
	  }
			  
	  else	{	  
	          $output.=$this->renderForm();			  
			  $output.='<br/>'.$this->renderProductOrders();	  
			}  
              
			  $output.='<br/>'.$this->InnovativesLabs().'<br/>'.$this->displayAdvertising();
            
          return $output;
    }
    

    
    

    
    public function renderForm()
    {
            $id_lang = (int) Context::getContext()->language->id;
            //$products = Product::getProducts($id_lang, 0, 1000, 'id_product', 'DESC');
			$cart_rules=$this->getCartsRules($id_lang);
			$employees=Employee::getEmployees();
            
            $this->fields_value['id_cart_rule'] = Tools::getValue('id_cart_rule');
			$this->fields_value['id_employee'] = Tools::getValue('id_employee');
            $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(                    
                        array(
                    'type' => 'select',
                    'label' => $this->l('Select a Cart Rule'),
                    'name' => 'id_cart_rule',

                    'options' => array(
                        'query' =>$cart_rules ,
                        'id' => 'id_cart_rule',
                        'name' => 'name',

                    ),
                    'desc' => $this->l('Select a Rule and associate it to a salesman.'),
                      ),
					  
					   array(
                    'type' => 'select',
                    'label' => $this->l('Select a Salesman'),
                    'name' => 'id_employee',

                    'options' => array(
                        'query' =>$employees ,
                        'id' => 'id_employee',
                        'name' => 'firstname',

                    ),
                    'desc' => $this->l('Select a Salesman and associate it to a code.'),
                      ),
                    
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );

            $helper = new HelperForm();
            $helper->show_toolbar = false;
            $helper->table = $this->table;
            $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
            $helper->default_form_language = $lang->id;
            $e_lang_var_one=Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG');
            $e_lang= $e_lang_var_one ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
            $helper->allow_employee_form_lang=$e_lang ;
            $this->fields_form = array();

            $helper->identifier = $this->identifier;
            $helper->submit_action = 'submit'.$this->name;
            $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).
            '&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
            $helper->token = Tools::getAdminTokenLite('AdminModules');
            $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

            return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
          
          return array(            
            'id_employee' => (int) Tools::getValue('id_employee'),
			'id_cart_rule' => (int) Tools::getValue('id_employee'),
        );
    }
    
    
	
	public function getProductOrders($id_product)
	{
		return Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'order_detail` WHERE `product_id` = '.(int)$id_product);
	}
	
	
	  
	public  function  renderProductOrders(){
	
	$id_lang=(int)Context::getContext()->language->id; 
	$id_product=(int)Tools::getValue('id_product');
	$SalesmanVoucher=new SalesmanVoucher();
	$orders=$SalesmanVoucher->getAllRelatedVouchers();
	
    $this->context->smarty->assign(
      array( 		  
		  	  
          'orders_list'=>$orders,
          'token'=>Tools::getAdminTokenLite('AdminModules'),			 
		  
            )
         );   
	  
		return $this->display(__FILE__, 'renderRelatedVouchers.tpl');
 
     }
 
     
 
   
     public function InnovativesLabs(){	  
		return $this->display(__FILE__, 'innovativeslabs.tpl');	
	  }  
	  
	        public function displayAdvertising()
      {
		$html= '
		<br/>
		<fieldset>
			<legend><img src="'.$this->_path.'img/more.png" alt="" title="" /> '.$this->l('More Modules & Themes ').'</legend>	
			<iframe src="http://prestatuts.com/advertising/prestashop_advertising.html" width="100%" height="420px;" border="0" style="border:none;"></iframe>
			</fieldset>';
			
	   return $html;		
    }


       public function addVoucher(){	
	   
	   $output='';
	   $id_lang=(int)Context::getContext()->language->id; 
	   
	    
	       
	   
     if(Tools::isSubmit('submit'.$this->name)){ 
          
	   $id_cart_rule=Tools::getValue('id_cart_rule');		 
	   $voucher_name=SalesmanVoucher::getNameById($id_cart_rule,$id_lang);   //Tools::getValue('voucher_name');
	   $voucher_code=SalesmanVoucher::getCodeById($id_cart_rule);//Tools::getValue('voucher_code');
	   $id_employee=Tools::getValue('id_employee');
       
	   if(SalesmanVoucher::verifyByCode($voucher_code) !=''){         
		$output=$this->displayError($this->l('Please remember duplicated Voucher codes are not allowed.'));
       } else{
	   	
	   
   if($voucher_name !='' || $voucher_code!='' || $id_employee!='' || $id_cart_rule!=''){
		
        $voucherObj =new SalesmanVoucher();
        
		$voucherObj->voucher_name=$voucher_name;
		$voucherObj->voucher_code=$voucher_code;
		$voucherObj->id_employee=$id_employee;
		$voucherObj->id_cart_rule=$id_cart_rule;
		
    if(!$voucherObj->add()){$output= $this->displayError($this->l('An error has occurred: Can\'t save the current object'));	}
       else{
           
        
		$output=$this->displayConfirmation($this->l('Your Code has been successfully added.'));
		
		}
		
		} else {$output=$this->displayError($this->l('All Field are required'));} 
      }   
	  }
	  return $output;
   }
   
   
   public  function getCartsRules($id_lang)
	{
		return Db::getInstance()->executeS('
			SELECT cr.*, crl.*
			FROM '._DB_PREFIX_.'cart_rule cr
			LEFT JOIN '._DB_PREFIX_.'cart_rule_lang crl ON (cr.id_cart_rule = crl.id_cart_rule AND crl.id_lang = '.(int)$id_lang.')
			
			');
	}  
   
   
   public  function  renderCodeDetails(){
	
	$id_lang=(int)Context::getContext()->language->id; 
	$id_salesman_voucher=(int)Tools::getValue('id_salesman_voucher');
	$SalesmanVoucher=new SalesmanVoucher($id_salesman_voucher);
	$id_cart_rule=$SalesmanVoucher->id_cart_rule;
	$customers=$SalesmanVoucher::usedByCustomers($id_cart_rule);
	
	
    $this->context->smarty->assign(
      array( 		  
		  'customers'=>$customers,	  
          'SalesmanVoucher'=>$SalesmanVoucher,
          'token'=>Tools::getAdminTokenLite('AdminOrders'),	
          'url_back'=>AdminController::$currentIndex.'&configure='.$this->name.'&token='.Tools::getAdminTokenLite('AdminModules'), 		  
		  
            )
         );   
	  
		return $this->display(__FILE__, 'renderCodeDetails.tpl');
 
     }
 
   
   	
    
}
